INA219 CURRENT SENSOR LIBRARY FOR PROTEUS - V1.0 (the GY-219 module and a DC electronic load)
Designed by The Engineering Projects
www.TheEngineeringProjects.com

IMPORTANT LINKS
Article (read it first - pictures, step by step, every feature explained):
  https://www.theengineeringprojects.com/2026/10/ina219-current-sensor-library-for-proteus-v1-0.html
Report a bug or suggest a feature (our forum):
  https://www.theengineeringprojects.com/forum/category/ina219-current-sensor-proteus-library
The demo runs on our Arduino UNO V4.0 (included) - working LEDs, RESET and a
built-in serial monitor, no Virtual Terminal to wire - its own article:
  https://www.theengineeringprojects.com/2026/10/arduino-uno-library-for-proteus-v40.html
The built-in monitor is our TEP Serial Monitor Advance - its own article:
  https://www.theengineeringprojects.com/2026/10/serial-monitor-advance-proteus-library.html
Support us (the libraries are free):
  https://www.theengineeringprojects.com/donate

FILE STRUCTURE
INA219-Current-Sensor-TEP-v1.0/
|-- Proteus Library Files/
|   |-- ArduinoV4TEP.LIB                              201.9 KB   TEP Arduino boards V4.0 (UNO), to LIBRARY
|   |-- TEPINA219.LIB                                  62.6 KB   the GY-219 / INA219 + the DC load, to LIBRARY
|-- Proteus Model Files/
|   |-- TEPARDUINO.DLL                                883.5 KB   the Arduino board model, to MODELS
|   |-- TEPINA219.DLL                                 319.5 KB   the INA219 / load model, to MODELS
|-- Proteus Simulation/
|   |-- INA219_Demo.hex                                38.1 KB   both UNOs (demo sketch V1.0)
|   |-- INA219-Current-Sensor-ArduinoUnoV4.pdsprj      25.1 KB   demo: 2 UNOs, each + GY-219 + load
|   |-- TEPARDUINO.DLL                                883.5 KB   copy of the board model
|   |-- TEPINA219.DLL                                 319.5 KB   copy of the model
|-- Arduino Code/
|   |-- INA219_Demo/INA219_Demo.ino                     4.6 KB   the demo sketch (source of the .hex)
|-- README.txt                                        ~25.4 KB   this file
Total: 2.70 MB (unzipped). The C++ source code of the model is not included.

WHAT IS IT?
A simulation model of the GY-219 module - the Texas Instruments INA219
current, voltage and power monitor with its 0.1 ohm shunt - and a DC
electronic load to measure. Our own models, not a part that shows a number:
  * The shunt is a real 0.1 ohm resistor between VIN+ and VIN- in the analog
    simulation: the current of your circuit flows through it. The INA219
    measures the shunt voltage (VIN+ to VIN-, 10 uV a step) and the bus
    voltage (VIN- to GND, 4 mV a step) from that simulation.
  * The chip as the datasheet describes it: a register pointer and six 16-bit
    registers over I2C (address 0x40), MSB first - Configuration (power-on
    0x399F), Shunt Voltage, Bus Voltage (with the CNVR and OVF flags), Power,
    Current and Calibration (power-on 0). Current = Shunt x Cal / 4096 and
    Power = Current x Bus / 5000; both stay 0 until the calibration is
    written.
  * The ADC: 9 to 12 bits (84 to 532 us) or averaging of 2 to 128 samples
    (1.06 to 68.10 ms) for the shunt and the bus; continuous or triggered
    modes, power-down, ADC off; the PGA (+-40, 80, 160 or 320 mV) and the bus
    range (16 or 32 V) clip the registers; 10 uV of noise (property NOISE).
  * The classic mistakes, each with a clear note: Current and Power read
    before the calibration (0), a current over the PGA's range (the reading
    stops at a round number), a calibration that overflows the Current
    register (OVF), a bus over the range, the wires swapped (a negative
    current), a register that is not there.
  * The TEP DC load draws a set current (0 to 4 A) from whatever feeds it:
    its DC LOAD panel has - / + (10 mA a click), six presets (LED 20 mA, UNO
    50 mA, SERVO 250 mA, MOTOR 800 mA, LAMP 1.5 A, HEATER 3.5 A) and an ON /
    OFF switch; its display shows the current it draws. The INA219's pop-up
    window can set the load too.
The module is drawn at about three times its real size: the purple GY-219
board with the INA219 in its SOIC-8, the R100 shunt, the pull-ups, the A0 /
A1 jumpers, the header VCC GND SCL SDA on the left and the blue screw terminal
VIN+ / VIN- on the right. ON the board, as TEP additions: the SIMPLE /
ADVANCE badge, the PWR, I2C (a transaction) and OVER (the PGA or the bus
clips, or OVF) LEDs and the panel button. The LEDs, the badge, the button and
the panels are TEP additions; the real module has none of them.

THREE DEVICES IN ONE LIBRARY (search "INA219" or "DCLOAD" in Pick Devices):
  Simple    INA219TEP      "INA219 Current Sensor (GY-219) V1.0 - Simple"
  Advance   INA219ADVTEP   (the same, "- Advance")
            (pins VCC GND SCL SDA on the left, VIN+ VIN- on the right;
            category Sensors > Current)
  Load      DCLOADTEP      "DC Electronic Load (0 - 4 A) V1.0"
            (pins + and - on the left: + in line with the INA219's VIN-)
  Simple    On-Sheet Panel: the STATUS panel under the module - the banner
            (MEASURING - BUS 11.920 V, SHUNT 80.00 mV, CURRENT 800.1 mA,
            POWER 9.536 W / NO CALIBRATION YET / OVF / the latest warning in
            red), the readouts STATE, BUS (V), SHUNT (mV), CURRENT (mA),
            POWER (mW), THE LOAD, CALIBRATION, PGA RANGE, CONVERSIONS, READS
            and the last 4 events. The red X closes the panel, PANEL: ON /
            OFF on the board opens it.
  Advance   Pop-Up Panel: only the module on the schematic; at Run a TEP
            pop-up window "TEP INA219 Advance" opens - the look of the TEP
            Serial Monitor. Tabs Sensor, Event log and Tests; gear and ? icons
            for Settings and Help; the palette icon switches the theme:
              Sensor     the load's six presets and its switch on the
                         toolbar; THE CIRCUIT (the supply, the shunt with its
                         voltage, the current, the load; the load's current
                         with -100 / -10 / +10 / +100 mA); THE INA219 (the
                         banner, the bus, the shunt, the current and the
                         power as its registers hold them); THE REGISTERS
                         (all six decoded); THE LAST I2C TRANSACTION, BYTE BY
                         BYTE
              Event log  power, the reads and writes, the load, notes,
                         warnings; filters All / I2C / Warnings, Pause, Clear
              Tests      three tools - I2C, Readings, Calibration & ranges
                         (THE TEST TOOLS)
              Settings   theme, text size, open at Run, window size
              Help       report a bug, suggest a feature, article, updates,
                         donate, forum; Copy diagnostics for a bug report
            The OPEN PANEL button on the board opens the window again.
All three devices use one model, TEPINA219.DLL.

TEST STATUS
V1.0: verified in Proteus 8.5 on 17 Oct 2026 (the demo project as shipped:
two Arduino UNO V4.0 boards with their built-in monitors; node 1 with the
Simple GY-219 on +12V and a DC load at 800 mA, node 2 with the Advance
GY-219 on +5V and a DC load at 250 mA).
What the runs showed:
  * Both UNOs read from the start: node 1 "Bus 11.920 V  Shunt 80.00 mV
    Current 800.1 mA  Power 9536 mW", node 2 "Bus 4.972 V  Shunt 25.00 mV
    Current 250.1 mA  Power 1242 mW"; the energy adds up line by line.
  * Node 1, LD1's DC LOAD panel with the real mouse (3 wheel steps on U1 and
    LD1): LAMP 1.5 A - "Current 1500.1 mA  Power 17772 mW", the load's
    display 1.500; CAL 400mA - "Shunt 40.00 mV  Current 400.0 mA" (the PGA's
    +-40 mV), U1's OVER LED and red banner; CAL 2A and the switch - "Current
    0.1 mA  Power 0 mW"; MOTOR 800 mA again; U1's red X and PANEL.
  * U2's pop-up: LAMP 1.5 A; CAL 400mA - 400.0 mA; CAL 1A and HEATER 3.5 A -
    "Shunt 320.00 mV  Current 1310.7 mA" (the PGA clips at 3.2 A and the
    Current register overflows: OVF); CAL 2A; RAW - "RAW:  0h 399F  1h 09C2
    2h 26E2  3h 026D  4h 09C4  5h 1000" (CNVR set in 02h); SLEEP, then MOTOR
    800 mA - the readings stayed at 250.1 mA; WAKE - 800.1 mA; the Event log
    and the three tools. No I2C error: 272 reads and 142 writes on each node.
  * 71.0 s of simulation took 136 s - about 0.5 x real time with the pop-up
    and both monitors open.
  Plus automatic checks on a PC, 0 failed: 53 on the model (a bit-level I2C
  master doing what the Adafruit INA219 library does over Wire: the
  power-on values, Current and Power before the calibration, 800 mA at 12 V,
  CNVR, the three calibrations, OVF, the PGA and bus ranges, a reversed
  current, power-down, triggered conversions, averaging, a wrong register, a
  read-only register, RST, the address, the noise) and 6 on the pop-up; the
  demo project read back from disk (96 checks: devices, pins, wires, labels;
  no wire through a part, no wire crossing).

INSTALLATION (about 2 minutes)
1. Close Proteus. Extract the WHOLE ZIP to a normal folder (e.g. Desktop).
2. Copy everything in "Proteus Library Files" (TEPINA219.LIB with the three
   parts, and our Arduino library V4.0, ArduinoV4TEP.LIB, with the ARDUINO
   UNO V4.0 used by the demo) to the LIBRARY folder of Proteus, for example:
     C:\Program Files (x86)\Labcenter Electronics\Proteus 8 Professional\LIBRARY
   (on some PCs: C:\ProgramData\Labcenter Electronics\Proteus 8 Professional\
   LIBRARY - use the folder that already holds Proteus's own .LIB files).
3. Copy TEPINA219.DLL and TEPARDUINO.DLL from "Proteus Model Files" to the
   MODELS folder (...\Proteus 8 Professional\MODELS).
   ArduinoV4TEP.LIB and TEPARDUINO.DLL are the files of our Arduino Library
   V4.0 - if you have it, they are the same.
4. Delete TEPINA219.IDX from the LIBRARY folder if it is there (Proteus makes
   a new index).
5. Start Proteus. In Pick Devices (P) search "INA219" or "DCLOAD".

RUN THE DEMO
"Proteus Simulation\INA219-Current-Sensor-ArduinoUnoV4.pdsprj" - keep the .hex
file and the two DLLs beside the project.
  ARD1: Arduino UNO V4.0 + U1 = a GY-219 (Simple) on a +12V supply with LD1,
        a DC load at 800 mA (a 12 V motor).
  ARD2: Arduino UNO V4.0 + U2 = a GY-219 (Advance) on a +5V supply with LD2
        at 250 mA (a 5 V servo).
  Both UNOs run INA219_Demo.hex (the Adafruit INA219 library) and each has
  its serial monitor built in (window "TEP Arduino UNO - ARD1" / "- ARD2").
  1. Press Run. Both UNOs' monitor windows open (9600 baud) and so does the
     pop-up of U2 (move it aside - it opens over the schematic).
  2. Each UNO prints the bus voltage, the shunt voltage, the current, the
     power and the energy so far, every second.
  3. Change the load on LD1's / LD2's DC LOAD panel or in U2's pop-up; switch
     it off and on.
  4. Type CAL 400mA: the 16 V / 400 mA calibration - with 800 mA the reading
     stops at 400.0 mA (the PGA's +-40 mV); CAL 2A brings it back. RAW shows
     the six registers; SLEEP powers the INA219 down (the readings freeze),
     WAKE wakes it. See THE DEMO SKETCH for all commands.
  5. U1: close its panel with the red X, open it with PANEL on the board.
     U2 (Advance): Sensor, Event log, and Tests - I2C, Readings,
     Calibration & ranges.
Closed a monitor window? Click the UNO's USB port.

WIRING (the same in Proteus and on a real board)
  GY-219 module   Arduino UNO              GY-219 module   the circuit
  VCC             5V (3.3 V works too)     VIN+            the supply's +
  GND             GND                      VIN-            the load's +
  SCL             A5 (= the SCL pin)       (the load's - and the supply's -
  SDA             A4 (= the SDA pin)        go to GND, shared with the UNO)
In the sketch (Adafruit INA219 library):
  Adafruit_INA219 ina219;                    // address 0x40
  ina219.begin();                            // setCalibration_32V_2A()
  float v = ina219.getBusVoltage_V();        // VIN- to GND
  float mA = ina219.getCurrent_mA();
  float mW = ina219.getPower_mW();
The serial monitor needs no wires: it is built into the Arduino UNO V4.0.
SDA and SCL reach their UNO through net labels - SDA_1 / SCL_1 (node 1),
SDA_2 / SCL_2 (node 2): the same name = connected. The supplies are Proteus
power terminals (+12V, +5V); the UNO's internal pull-ups hold the I2C bus.
REAL HARDWARE:
 * The INA219 measures on the high side: the shunt between the supply and the
   load; the grounds of the supply, the load and the Arduino must meet.
 * The GY-219's 0.1 ohm shunt: +-320 mV (PGA /8) = +-3.2 A; the INA219's
   inputs take up to 26 V.
 * The GY-219 has 10 kohm pull-ups to VCC on SDA / SCL.
 * Up to four modules on one bus with the A0 / A1 jumpers: 0x40, 0x41, 0x44,
   0x45 (property ADDRESS).

THE TEST TOOLS (Advance, Tests tab) - what they really measure
Every tool reads the model during the running simulation; each shows one
"Good for:" line and, where it judges, a verdict per row (green = fine, amber
= check, red = wrong).
  I2C                   Good for: a sensor that does not answer, Current and
                        Power stuck at 0, a configuration that does not
                        stick. The address, the register reads (and the CNVR
                        polls), the writes to the configuration and the
                        calibration, reads of Current / Power without the
                        calibration, wrong registers, the conversions.
  Readings              Good for: what the sketch reads and writes, and in
                        which order. The last 12 transactions: time, kind,
                        register, word and its value in units.
  Calibration & ranges  Good for: a current that stops at a round number,
                        OVF, a wrong power, choosing a calibration. The real
                        current, the PGA range, the bus range, the
                        calibration's Current_LSB and the current where the
                        Current register overflows; a table of the Adafruit
                        library's three calibrations against this circuit.

THE DEMO SKETCH ON THE SERIAL MONITOR (INA219_Demo V1.0)
  RUN        the readings go on (every second)
  STOP       no more readings
  CAL 2A     setCalibration_32V_2A() (the default: 32 V, 0.1 mA a step)
  CAL 1A     setCalibration_32V_1A() (32 V, 0.04 mA a step, up to 1.31 A)
  CAL 400mA  setCalibration_16V_400mA() (16 V, 0.05 mA, up to 400 mA)
  RAW        the six registers by hand with Wire: 0h to 5h in hex
  SLEEP      powerSave(true): the INA219 powers down
  WAKE       powerSave(false): converting again
  HELP       the command list
Commands are not case-sensitive; type them in the UNO's built-in monitor and
press Enter.

EXPECTED MONITOR OUTPUT (node 1)
  TEP INA219 - demo (Adafruit INA219 library)
  SDA on A4, SCL on A5, address 0x40
  CAL: 32 V, 2 A (0.1 mA a step)
  Commands: RUN | STOP | RAW | HELP
            CAL 2A | CAL 1A | CAL 400mA
            SLEEP | WAKE
  #1  Bus 11.916 V  Shunt 80.00 mV  Current 800.1 mA  Power 9532 mW  Energy 0.00 mWh
  #2  Bus 11.920 V  Shunt 80.00 mV  Current 800.1 mA  Power 9536 mW  Energy 2.71 mWh
(The last digits move a little: the noise - property NOISE.)

PROPERTIES (double-click the part > Edit Properties)
  INA219 (GY-219):
  ADDRESS    the I2C address, 0x40 (default), 0x41, 0x44 or 0x45 (the A0 /
             A1 jumpers)
  NOISE      the shunt ADC's noise in uV RMS (default 10 = one step; 0 =
             none)
  PANEL      Simple only: the STATUS panel at the start, OPEN or CLOSED
  DC load:
  CURRENT    the current at the start, in mA (default 800; 0 to 4000)
  LOAD       ON or OFF at the start (default ON)
Every run starts again from the properties, and the INA219 from its
power-on registers. The demo's UNOs (ARDUINO UNO V4.0): PROGRAM
INA219_Demo.hex, MONITOR YES (the built-in monitor), BAUD 9600, AUTOOPEN YES,
BOOTLOADER YES.

LINKS.INI (OPTIONAL)
The Help page cards of the Advance device open web pages. To point them
somewhere else without a new DLL, put a text file named links.ini next to
TEPINA219.DLL with lines KEY=URL, for example:
  ARTICLE=https://www.theengineeringprojects.com/...
Keys: WEBSITE, FORUM, BUG_REPORT, FEATURE_REQUEST, ARTICLE, USER_GUIDE,
UPDATE_CHECK, DONATE. Only http:// and https:// links are used; lines starting
with # are comments.

TROUBLESHOOTING
* "INA219 not found": no power on VCC / GND, SDA / SCL swapped or missing, or
  another address (the PWR LED is off, or the I2C LED never flashes).
* Current and Power 0: the calibration was never written (begin() writes it).
* The current stops at a round number (400.0 mA, 1310.7 mA, 3200 mA): the
  PGA's range or the Current register's - see Calibration & ranges; the
  OVER LED is lit.
* A negative current: VIN+ and VIN- are swapped.
* The bus voltage stops at 16 V: the 16 V range (CAL 400mA) - use 32 V.
* Nothing changes any more: the INA219 is powered down (SLEEP) - WAKE.
* The parts are not simulated: TEPINA219.DLL is missing from MODELS and from
  the project folder. No UNO / no monitor window: TEPARDUINO.DLL is missing,
  or click the UNO's USB port.
* Advance: the pop-up does not appear - click OPEN PANEL on the board, or turn
  "Open the panel at Run" on its Settings page back on.

BUG REPORTS AND FEATURE REQUESTS
Please post them in our forum with a screenshot, the Serial Monitor text, the
simulation log and (Advance) the Copy diagnostics text:
  https://www.theengineeringprojects.com/forum/category/ina219-current-sensor-proteus-library

SUPPORT US
This library is free. If it saves you time, please support our work:
  https://www.theengineeringprojects.com/donate

WEBSITE
  https://www.theengineeringprojects.com/

LICENCES AND THIRD-PARTY NOTES
* The INA219 / GY-219 model and the DC load (TEPINA219.DLL), the symbols and
  artwork and the Arduino Library V4.0 (ArduinoV4TEP.LIB / TEPARDUINO.DLL,
  with its built-in TEP Serial Monitor Advance) are made by The Engineering
  Projects. The model is an independent implementation written from the
  INA219 datasheet. The model uses only standard Windows libraries; no Visual
  C++ redistributable is needed.
  The C++ source code is not included.
* Arduino UNO V4.0 (ArduinoV4TEP.LIB / TEPARDUINO.DLL, our Arduino Library
  V4.0 - its microcontroller is Proteus's own AVR model): The Engineering
  Projects, https://www.theengineeringprojects.com/2026/10/arduino-uno-library-for-proteus-v40.html
* The demo sketch uses the Adafruit INA219 library 1.2.3 (BSD licence) and
  Adafruit BusIO 1.17.4 (MIT licence); they are not shipped here - install
  "Adafruit INA219" (by Adafruit) from the Library Manager of the Arduino IDE
  (it installs Adafruit BusIO with it). Their source code:
    https://github.com/adafruit/Adafruit_INA219/tree/1.2.3
    https://github.com/adafruit/Adafruit_BusIO/tree/1.17.4
  The .hex file contains compiled code of both, so their licences:
  Adafruit INA219 library:
    Software License Agreement (BSD License)
    Copyright (c) 2012, Adafruit Industries
    All rights reserved.
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
    1. Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.
    3. Neither the name of the copyright holders nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
    EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
    WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
    DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
    (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
    ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  Adafruit BusIO:
    The MIT License (MIT)
    Copyright (c) 2017 Adafruit Industries
    Permission is hereby granted, free of charge, to any person obtaining a
    copy of this software and associated documentation files (the
    "Software"), to deal in the Software without restriction, including
    without limitation the rights to use, copy, modify, merge, publish,
    distribute, sublicense, and/or sell copies of the Software, and to permit
    persons to whom the Software is furnished to do so, subject to the
    following conditions:
    The above copyright notice and this permission notice shall be included
    in all copies or substantial portions of the Software.
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
    OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
    NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
    DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
    OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
    USE OR OTHER DEALINGS IN THE SOFTWARE.
* The .hex file is built from the demo sketch, these two libraries and the
  Arduino AVR core 1.8.6 (with its Wire and SPI libraries), which includes
  LGPL-licensed code; its source code is available at
  https://github.com/arduino/ArduinoCore-avr/tree/1.8.6
  The demo sketch's source is in "Arduino Code", so the .hex can be rebuilt
  with other versions of these libraries (REBUILDING THE FIRMWARE).
* Proteus is a product of Labcenter Electronics and is not included. Arduino is
  a trademark of Arduino SA. INA219 is a product of Texas Instruments. This
  library is not made or endorsed by Texas Instruments, Adafruit, the makers
  of the GY-219 module or Labcenter.

REBUILDING THE FIRMWARE (OPTIONAL)
The HEX file is supplied; Arduino IDE is not needed to run the demo. To edit the
sketch, install "Adafruit INA219" by Adafruit from the Library Manager, open
Arduino Code\INA219_Demo\INA219_Demo.ino in the Arduino IDE, select Arduino Uno
and use Sketch > Export Compiled Binary. Replace the simulation's .hex with the
exported HEX. The sketch needs 13,858 bytes of flash and 557 bytes of RAM.

MODEL SCOPE AND LIMITS
Modelled: the I2C slave (the pointer, the six registers MSB first, the
address), the power-on values and RST, the configuration (BRNG, PGA, BADC,
SADC, MODE), the conversion times and averaging, continuous and triggered
modes, power-down and ADC off, the shunt and bus registers with their ranges,
the Current and Power maths with the calibration, CNVR (cleared by reading
Power or a new mode) and OVF, the noise; the 0.1 ohm shunt between VIN+ and
VIN-, a 320 kohm bus input on VIN-, the chip's 1 mA on VCC; the DC load as a
constant-current sink.
How the parts work with the circuit: the shunt, the bus input and the load are
in the analog simulation; the INA219 reads VIN+ - VIN- and VIN- - GND from it.
Proteus runs the Arduino's SCL / SDA edges as digital events; the model takes
each with its exact time and pulls SDA low to acknowledge and to send.
Not modelled: the INA219's offset and gain errors (the datasheet: +-10 to
+-100 uV offset, +-0.5 % gain), the SMBus timeout (28 ms) and the SMBus alert
response, the shunt's temperature drift and self-heating, the bias currents
of the inputs beyond the 320 kohm bus input; the load has no power limit.

VERSION
TEP INA219 current sensor library V1.0 (Oct 2026). Devices INA219TEP /
INA219ADVTEP / DCLOADTEP (TEPINA219.LIB / TEPINA219.DLL). Demo sketch
INA219_Demo V1.0 (Adafruit INA219 1.2.3, Adafruit BusIO 1.17.4). Demo board:
ARDUINO UNO V4.0 (TEP Arduino Library V4.0) with its built-in serial monitor.
