// TEP INA219 Current Sensor Library for Proteus V1.0 - demo sketch for the Arduino UNO
// The Engineering Projects - www.TheEngineeringProjects.com
//
// A GY-219 module (the INA219 current / voltage / power monitor) on the I2C bus: SDA on A4, SCL on A5, read with the Adafruit INA219
// library every second. The supply feeds the load through the module's 0.1 ohm shunt (VIN+ to VIN-). Each line shows the bus
// voltage, the shunt voltage, the current and the power; the sketch adds up the energy. Change the load on its DC LOAD panel and
// watch the readings follow. CAL 2A / CAL 1A / CAL 400mA pick one of the library's calibrations; RAW shows the six registers.
// Type HELP for the commands.
//
// Library: Adafruit INA219 1.2.3 by Adafruit (BSD) - https://github.com/adafruit/Adafruit_INA219
//          it needs Adafruit BusIO 1.17.4 (MIT) - https://github.com/adafruit/Adafruit_BusIO

#include <Wire.h>
#include <Adafruit_INA219.h>

const uint8_t INA_ADDR = 0x40;                 // the INA219's I2C address (A0 / A1 open)

Adafruit_INA219 ina219(INA_ADDR);
bool running = true;
unsigned long period = 1000;                   // ms between two readings
unsigned long nextAt = 0, lastAt = 0;
uint16_t count = 0;
float energy_mWh = 0;
char line[24];
uint8_t lineLen = 0;

void help() {
  Serial.println(F("Commands: RUN | STOP | RAW | HELP"));
  Serial.println(F("          CAL 2A | CAL 1A | CAL 400mA"));
  Serial.println(F("          SLEEP | WAKE"));
}

// one reading: the bus voltage (VIN- to GND), the shunt voltage (VIN+ to VIN-), the current and the power from the INA219's registers
void readAll() {
  const float bus = ina219.getBusVoltage_V();
  const float shunt = ina219.getShuntVoltage_mV();
  const float current = ina219.getCurrent_mA();
  const float power = ina219.getPower_mW();
  const unsigned long now = millis();
  if (lastAt) energy_mWh += power * (now - lastAt) / 3600000.0;   // mW x hours
  lastAt = now;
  Serial.print('#'); Serial.print(++count);
  Serial.print(F("  Bus ")); Serial.print(bus, 3);
  Serial.print(F(" V  Shunt ")); Serial.print(shunt, 2);
  Serial.print(F(" mV  Current ")); Serial.print(current, 1);
  Serial.print(F(" mA  Power ")); Serial.print(power, 0);
  Serial.print(F(" mW  Energy ")); Serial.print(energy_mWh, 2); Serial.println(F(" mWh"));
}

// the six registers by hand: the pointer, then 2 bytes MSB first
uint16_t readRegister(uint8_t reg) {
  Wire.beginTransmission(INA_ADDR);
  Wire.write(reg);
  Wire.endTransmission();
  Wire.requestFrom(INA_ADDR, (uint8_t)2);
  const uint8_t msb = Wire.read(), lsb = Wire.read();
  return (uint16_t)msb << 8 | lsb;
}

void raw() {
  Serial.print(F("RAW:"));
  for (uint8_t r = 0; r < 6; r++) {
    const uint16_t v = readRegister(r);
    Serial.print(F("  ")); Serial.print(r, HEX); Serial.print(F("h "));
    for (int8_t s = 12; s >= 0; s -= 4) Serial.print((v >> s) & 0xF, HEX);
  }
  Serial.println();
}

void command(char* s) {
  if (!strcasecmp(s, "RUN")) { running = true; Serial.println(F("RUN: the readings go on")); }
  else if (!strcasecmp(s, "STOP")) { running = false; Serial.println(F("STOP: no more readings")); }
  else if (!strcasecmp(s, "CAL 2A")) { ina219.setCalibration_32V_2A(); Serial.println(F("CAL: 32 V, 2 A (0.1 mA a step)")); }
  else if (!strcasecmp(s, "CAL 1A")) { ina219.setCalibration_32V_1A(); Serial.println(F("CAL: 32 V, 1 A (0.04 mA a step)")); }
  else if (!strcasecmp(s, "CAL 400mA")) { ina219.setCalibration_16V_400mA(); Serial.println(F("CAL: 16 V, 400 mA (0.05 mA a step)")); }
  else if (!strcasecmp(s, "SLEEP")) { ina219.powerSave(true); Serial.println(F("SLEEP: the INA219 powers down")); }
  else if (!strcasecmp(s, "WAKE")) { ina219.powerSave(false); Serial.println(F("WAKE: converting again")); }
  else if (!strcasecmp(s, "RAW")) raw();
  else if (!strcasecmp(s, "HELP")) help();
  else { Serial.print(F("? ")); Serial.println(s); help(); }
  nextAt = millis() + period;
}

void setup() {
  Serial.begin(9600);
  Serial.println(F("TEP INA219 - demo (Adafruit INA219 library)"));
  Serial.println(F("SDA on A4, SCL on A5, address 0x40"));
  if (!ina219.begin()) Serial.println(F("INA219 not found - check the wiring"));
  else Serial.println(F("CAL: 32 V, 2 A (0.1 mA a step)"));   // begin() calls setCalibration_32V_2A()
  help();
  nextAt = millis() + 100;
}

void loop() {
  while (Serial.available()) {
    const char c = Serial.read();
    if (c == '\r' || c == '\n') { if (lineLen) { line[lineLen] = 0; command(line); lineLen = 0; } }
    else if (lineLen < sizeof line - 1) line[lineLen++] = c;
  }
  if (running && (long)(millis() - nextAt) >= 0) { readAll(); nextAt = millis() + period; }
}
