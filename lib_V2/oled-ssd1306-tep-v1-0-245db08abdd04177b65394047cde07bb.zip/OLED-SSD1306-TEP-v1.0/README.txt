OLED SSD1306 LIBRARY FOR PROTEUS - V1.0
Designed by The Engineering Projects
www.TheEngineeringProjects.com

IMPORTANT LINKS
Article (read it first - pictures, step by step, every feature explained):
  https://www.theengineeringprojects.com/2026/10/oled-ssd1306-library-for-proteus-v1-0.html
Report a bug or suggest a feature (our forum):
  https://www.theengineeringprojects.com/forum/category/oled-proteus-library
The demo uses our TEP Serial Monitor Advance (included) instead of Proteus's
Virtual Terminal - its own article:
  https://www.theengineeringprojects.com/2026/10/serial-monitor-advance-proteus-library.html
Only text to show? Our LCD Library for Proteus V3.0 (16x2 and 20x4, parallel
and I2C):
  https://www.theengineeringprojects.com/2026/10/lcd-library-for-proteus-v30.html
Support us (the libraries are free):
  https://www.theengineeringprojects.com/donate

FILE STRUCTURE
OLED-SSD1306-TEP-v1.0/
|-- Proteus Library Files/
|   |-- ArduinoV3TEP.IDX                            0.8 KB   its index -> LIBRARY folder
|   |-- ArduinoV3TEP.LIB                           95.6 KB   TEP Arduino UNO (demo) -> LIBRARY folder
|   |-- TEPOLED12864.LIB                          112.4 KB   the 6 OLED devices -> LIBRARY folder
|   |-- TEPSERIALMON.LIB                           11.1 KB   TEP Serial Monitor Advance -> LIBRARY folder
|-- Proteus Model Files/
|   |-- TEPOLED.DLL                               323.0 KB   the OLED model -> MODELS folder
|   |-- TEPSERIALMON.DLL                          978.0 KB   Serial Monitor model -> MODELS folder
|-- Proteus Simulation/
|   |-- OLED_SSD1306_Demo.hex                      67.2 KB   both UNOs (demo sketch V1.0)
|   |-- OLED-SSD1306-ArduinoUnoV3.pdsprj           22.4 KB   demo: UNO 1 + Simple, UNO 2 + Advance
|   |-- TEPOLED.DLL                               323.0 KB   copy of the model so the demo runs as is
|   |-- TEPSERIALMON.DLL                          978.0 KB   copy of the monitor model
|-- Arduino Code/
|   |-- OLED_SSD1306_Demo/OLED_SSD1306_Demo.ino    11.8 KB   the demo sketch (source of the .hex)
|-- README.txt                                    ~30.0 KB   this file
Total: 2.88 MB (unzipped). The C++ source code of the model is not included.

WHAT IS IT?
A simulation model of the 0.96" OLED display module for Proteus 8: the
128x64-pixel SSD1306 OLED with the 4-pin I2C header (GND, VCC, SCL, SDA) that
sits in countless Arduino projects. Our own model, not a symbol on top of
Proteus's parts. It works with the Adafruit SSD1306 + Adafruit GFX libraries
and with any code that talks to an SSD1306 over I2C:
  * The I2C side as on the real module: the address 0x3C (or 0x3D), the
    acknowledge on SDA (open-drain, released to the pull-up), the control byte
    (0x00 = commands follow, 0x40 = data follows, single bytes with Co = 1),
    command parameters even when they come in separate transactions, and the
    clock measured (the SSD1306 is rated for 400 kHz).
  * The SSD1306 controller itself: its 1 KB display RAM (GDDRAM, 8 pages x 128
    columns, one byte = 8 pixels down), the three addressing modes
    (horizontal, vertical, page) with their column / page windows, contrast,
    inverse, entire display on, display on / off, start line, display offset,
    multiplex ratio, segment and COM remap, the COM pin setting, the clock, the
    charge pump and the continuous scrolling (left, right, diagonal, the
    vertical scroll area) done by the controller itself.
  * The charge pump: this module has no external high voltage, so the panel
    stays DARK until the sketch switches the pump on (8D 14) - exactly what
    SSD1306_SWITCHCAPVCC in display.begin() does.
  * The power-on RAM is random: until the first frame the glass shows dots,
    as a real module does for a moment.
  * The panel refresh (about 88 Hz) follows the clock and multiplex settings;
    the glass shows what the controller would show - a 128x32 setting on this
    128x64 glass looks wrong here too.
The part looks like the real module: the blue 27 x 28 mm board with its four
holes and the glass, drawn at TWICE the real size so the 128x64 pixels stay
readable on the schematic. While the simulation runs the pixels glow in the
glass colour and LEDs show what happens: PWR (power) and I2C (a transaction to
this address). The LEDs and the ADDRESS selector (0x3C / 0x3D) are
TEP additions: a real module has no LEDs and sets the address with a resistor
on the back (marked 0x78 = 0x3C, 0x7A = 0x3D).

SIX DEVICES IN ONE LIBRARY (search "OLED12864" in Pick Devices):
  Simple, white           device OLED12864WHITETEP
  Advance, white          device OLED12864WHITEADVTEP
  Simple, blue            device OLED12864BLUETEP
  Advance, blue           device OLED12864BLUEADVTEP
  Simple, yellow-blue     device OLED12864YELLOWBLUETEP
  Advance, yellow-blue    device OLED12864YELLOWBLUEADVTEP
  In Pick Devices each is called "OLED SSD1306 128x64 V1.0 <colour> - Simple"
  or "... - Advance".
  White, blue = one-colour glass. Yellow-blue = the two-colour glass: rows 0 -
  15 yellow, a small gap, rows 16 - 63 blue. The colours are fixed in the glass
  (it is not an RGB display) - put a header in the top 16 rows.
  Simple    On-Sheet Panel: the OLED STATUS panel under the board - the banner
            (READY - 128x64, I2C 0x3C, DISPLAY ON / WAITING FOR I2C / WRONG
            ADDRESS / DISPLAY OFF / DARK - THE CHARGE PUMP IS OFF / 128x32
            SETTINGS ON A 128x64 GLASS / MIRRORED or UPSIDE DOWN / NO POWER),
            the readouts DISPLAY, CHARGE PUMP, CONTRAST, ADDRESSING, SCROLL,
            VCC, I2C (the address and the clock), FRAME (the time one frame
            takes on the bus), WRITES and LOST (unknown commands and bytes sent
            without power), and the last 6 transfers. The red X closes the
            panel, PANEL: SHOWN / CLOSED on the board opens it again.
  Advance   Pop-Up Panel: only the module on the schematic; at Run a TEP pop-up
            window "TEP OLED SSD1306 Advance" opens - the look of the TEP Serial
            Monitor. Tabs Display, Bus log and Tests; gear and ? icons for
            Settings and Help; the palette icon switches the theme:
              Display   a big copy of the glass with GLASS Live / Freeze (hold a
                        frame) and PIXEL GRID Off / On (a line every 8 pixels
                        with the x / y numbers - Adafruit GFX's coordinates),
                        the controller's state (display, charge pump, contrast,
                        addressing, orientation, multiplex, COM pins, scroll),
                        the GDDRAM as stored with the write pointer, the
                        supply, frames and mapping
              Bus log   every command (with its parameters) and every run of
                        data bytes (up to 512): the time, the gap, CMD / DATA /
                        POWER, the bytes, what it means; filters All /
                        Commands / Data / Problems, Pause, Clear
              Tests     four tools - Init check, I2C bus, Speed, Pixels (see THE
                        TEST TOOLS below)
              Settings  theme, text size, open at Run, window size
              Help      report a bug, suggest a feature, article, updates,
                        donate, forum; Copy diagnostics for a bug report
            The OPEN PANEL button on the board opens the window again.
All six use the same model (TEPOLED.DLL).

CLICK THE BOARD (while the simulation runs)
  ADDRESS selector  0x3C / 0x3D: the OLED answers the other address at once.
                    The sketch keeps its old address until you reset the
                    Arduino - the panel then says WRONG ADDRESS and the glass
                    keeps its last picture, as a real module would. Written to
                    the simulation log. The start value is the ADDRESS property.
  PANEL / OPEN PANEL  the status panel (Simple) or the pop-up (Advance).

TEST STATUS
V1.0: verified in Proteus 8.5 on 12 Oct 2026 (the demo project as shipped: two
UNOs, both Serial Monitors and OLED2's pop-up open). What the run showed:
  * The project loads and starts cleanly. The sketch finds each OLED itself:
    U1 prints "OLED found at 0x3C", U2 "OLED found at 0x3D"; after the TEP logo
    the glasses show the dashboard - "TEP OLED 0x3C", the up time and the
    frame count in the header, "Hello, TEP" in big letters and a moving sine
    wave; OLED2's header in the yellow rows.
  * OLED1's panel: READY - 128x64, I2C 0x3C, DISPLAY ON; DISPLAY ON, CHARGE
    PUMP ON, CONTRAST 207, ADDRESSING HORIZONTAL, SCROLL OFF, VCC 5.00 V, I2C
    0x3C 400k, FRAME 36.0 ms, WRITES counting, LOST 0.
  * U1: TEXT Hi there! (the big line changes), STATUS (all lines listed).
  * U2: SCROLL RIGHT - the controller moves the whole picture by itself (the
    sketch stops redrawing), OLED2's pop-up shows SCROLL RIGHT.
  * OLED2 (Advance): Display; Bus log (SCROLL SETUP RIGHT, pages 0..7, every 5
    frames, then SCROLL ON); Init check - every row green and one amber row:
    Adafruit's begin() switches the display on before the first frame, so the
    random power-on RAM shows for a moment; display on 68 ms after power-on;
    I2C bus - 0x3D, 31 data bytes per transaction (Wire's 32-byte buffer), one
    address check to 0x3C and one to 0x3D (the sketch's search), SCL 400 kHz;
    Speed - 36.8 ms per full frame, at best 27 frames a second, the sketch sends
    2 a second, the bus 5 % busy, the panel refresh 87.6 Hz; Pixels (x 0, y 0 =
    page 0, column 0, bit 0 - the byte and its bits).
  * OLED1's panel closed with its red X and opened again with PANEL on the
    board. The ADDRESS selector moved to 0x3D at Run: the red banner WRONG
    ADDRESS - THE SKETCH WRITES TO 0x3C, THIS OLED IS 0x3D, a line in the
    simulation log, the glass keeps its last frame.
  * The four other devices (blue Simple, white Advance, yellow-blue Simple,
    blue Advance) ran the same demo in two test copies of the project.
  * Speed: about 0.62 x real time with both monitors and the pop-up open (two
    UNOs sending full frames at 400 kHz twice a second).
  Plus automatic checks on a PC, 0 failed: 46 with the REAL demo sketch and the
  UNMODIFIED Adafruit SSD1306 2.5.17 + Adafruit GFX 1.12.6 talking bit by bit
  (400 kHz) to the model - the glass equals Adafruit's own buffer after every
  frame (the logo, the dashboard, shapes, the bar, inverse, contrast,
  scrolling, finding a 0x3D board), 56 on the SSD1306 controller (every
  addressing mode and window, the remaps, multiplex, offset, start line, the
  charge pump, scrolling, parameters split over transactions, the power-on
  RAM), 4 on the pop-up pages with renders of every page, tool and glass; the
  demo project read back from disk (130 checks: devices, pins, wires, labels,
  no wire crossing).

INSTALLATION (about 2 minutes)
1. Close Proteus. Extract the WHOLE ZIP to a normal folder (e.g. Desktop).
2. Copy everything in "Proteus Library Files" (TEPOLED12864.LIB with the six
   devices, TEPSERIALMON.LIB and the TEP Arduino UNO V3 library ArduinoV3TEP.LIB
   / .IDX used by the demo) to the LIBRARY folder of Proteus, for example:
     C:\Program Files (x86)\Labcenter Electronics\Proteus 8 Professional\LIBRARY
   (on some PCs: C:\ProgramData\Labcenter Electronics\Proteus 8 Professional\
   LIBRARY - use the folder that already holds Proteus's own .LIB files).
3. Copy TEPOLED.DLL and TEPSERIALMON.DLL from "Proteus Model Files" to the
   MODELS folder (...\Proteus 8 Professional\MODELS).
4. Delete TEPOLED12864.IDX from the LIBRARY folder if there is one (Proteus
   makes a new index).
5. Start Proteus. In Pick Devices (P) search "OLED12864": you get the six
   devices (category Optoelectronics > Graphical LCDs).

RUN THE DEMO
"Proteus Simulation\OLED-SSD1306-ArduinoUnoV3.pdsprj" - keep the .hex file and
the two DLLs beside the project.
  UNO 1 (ARD1): OLED1 = white Simple OLED at 0x3C, Serial Monitor U1.
  UNO 2 (ARD2): OLED2 = yellow-blue Advance OLED at 0x3D, Serial Monitor U2.
  Both run OLED_SSD1306_Demo.hex - the same sketch finds either address.
  1. Press Run. Both monitor windows open (9600 baud) and so does OLED2's
     pop-up (move them aside - they open over the schematic). The OLEDs show
     the TEP logo for a second, then the dashboard: the address, the up time
     and the frame count, "Hello, TEP" and a moving sine wave; U1 / U2 print
     the start lines with the address found.
  2. U1's quick buttons: STATUS, TEXT Hi there!, BAR 75, LOGO.
     U2's quick buttons: STATUS, SHAPES, SCROLL RIGHT, DASH. Type more in the
     monitors - see THE DEMO SKETCH below.
  3. OLED1: close the panel with its red X, open it with PANEL on the board;
     click the ADDRESS selector to see WRONG ADDRESS (click again to go back).
  4. OLED2 (Advance): Display (try Freeze and the pixel grid), Bus log, and
     Tests - Init check, I2C bus, Speed, Pixels (click a pixel).
Closed a monitor window? Click OPEN MONITOR on the monitor part.

WIRING (the same in Proteus and on a real board)
  OLED pin   Arduino UNO
   GND       GND
   VCC       5V (or 3.3V)
   SCL       A5 (SCL)
   SDA       A4 (SDA)
In the sketch:
  Adafruit_SSD1306 display(128, 64, &Wire, -1);  // width, height, bus, no reset
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);     // charge pump on, the address
(the demo sketch tries 0x3C, then 0x3D, and uses what answers).
Serial Monitor RXD <- Arduino D1 (TX), Serial Monitor TXD -> Arduino D0 (RX),
Serial Monitor GND -> ground. RXD2 is not needed.
In the demo every OLED pin reaches the UNO through a short wire with a net
label - SDA_1 / SCL_1 (node 1), SDA_2 / SCL_2 (node 2), VCC and GND: the same
name = connected.
REAL HARDWARE:
 * Check the pin order printed on YOUR module: most are GND VCC SCL SDA, some
   are VCC GND SCL SDA - swapped supply pins can kill the module.
 * Nothing on the screen: run an I2C scanner (or the demo's SCAN). Most
   modules are 0x3C; the back says 0x78 (= 0x3C) or 0x7A (= 0x3D) next to the
   address resistor.
 * Adafruit_SSD1306 needs a 1 KB buffer in RAM: on an UNO (2 KB RAM) keep your
   own variables small - display.begin() returns false when there is no room
   (keep text in flash with F("...")).
 * 1.3" modules that look the same often carry an SH1106 chip, not an SSD1306:
   with SSD1306 code they show a garbled or shifted picture. They need another
   library (e.g. Adafruit SH110X or U8g2).
 * A 128x32 module needs display(128, 32, ...) and a 128x64 one (128, 64, ...)
   - the wrong size gives every second line or a stretched picture.
 * The module has its own regulator and SDA / SCL pull-ups; it runs from 3.3 V
   and from 5 V. 400 kHz I2C is fine (Adafruit uses it while sending a frame).
 * OLED pixels age: a static picture shown for months can burn in. Turn the
   display off (or dim it) when nobody looks.

THE TEST TOOLS (Advance, Tests tab) - what they really measure
Every tool reads the bus as the model sees it during the running simulation;
each shows one "Good for:" line and a verdict per row (green = fine, amber =
check, red = wrong).
  Init check    Good for: an OLED that stays dark, mirrored, upside down or
                striped - is the sketch's begin() right? The start-up since
                power-on against the datasheet: the first command (display
                off), the charge pump, the multiplex ratio and COM pins (right
                for 128x64?), the orientation (A1 + C8 = upright on this
                module), the addressing mode, the contrast, display on (and
                when), whether the RAM was written before the display came on,
                a verdict, and the start-up as the sketch sent it.
  I2C bus       Good for: a dark OLED - the wrong address, SDA / SCL swapped,
                the clock and Wire's 32-byte buffer. This OLED's address (and
                its address resistor), the address the sketch writes to (a red
                line when it is not this one), command and data transactions
                since Start, the data bytes per transaction (Wire sends at most
                31 after the 0x40 control byte), the address checks (a scanner
                / auto-detect), the SCL clock (measured, rated 400 kHz) and the
                last transactions with their bytes.
  Speed         Good for: slow animations - one full frame is 1024 bytes; at
                100 kHz it takes four times as long as at 400 kHz. The time per
                frame on the bus, the best frame rate possible, what the sketch
                really sends, how busy the bus is, the clock, and the panel's
                own refresh rate.
  Pixels        Good for: drawing code and bitmaps - click a pixel on the small
                glass: its RAM page, column and bit, the byte the RAM holds
                (with all 8 bits and the 16 bytes around it), its place in
                Adafruit's buffer and the drawPixel() line for it.

THE DEMO SKETCH ON THE SERIAL MONITOR (OLED_SSD1306_Demo V1.0)
  HELP              the command list
  STATUS            the address, the screen, the text, the lower part,
                    contrast / inverse / scroll / display, the frames sent
  SCAN              every I2C device on the bus (0x08 - 0x77)
  TEXT <text>       the big line (10 characters; longer text is cut)
  SIZE <1-3>        its text size
  GRAPH             the moving sine wave again
  BAR <0-100>       a bar instead of the wave
  LOGO              the TEP logo (drawBitmap)
  SHAPES            rectangles, circles, a triangle, lines (Adafruit GFX)
  DASH              the dashboard again
  INVERT ON|OFF     inverse (the controller inverts, the RAM stays)
  CONTRAST <0-255>  the brightness (Adafruit's default 207)
  DISPLAY ON|OFF    the panel on / off (the RAM is kept)
  SCROLL LEFT|RIGHT|DIAG|STOP  the controller's own scrolling
  CLEAR             an empty screen (DASH brings the dashboard back)
Commands are not case-sensitive. Monitor quick buttons in the demo: U1 STATUS,
TEXT Hi there!, BAR 75, LOGO; U2 STATUS, SHAPES, SCROLL RIGHT, DASH.
The dashboard is redrawn twice a second - each redraw sends the whole 1 KB
frame (Adafruit's display()); while the controller scrolls the sketch sends
nothing.

EXPECTED MONITOR OUTPUT (U1)
  OLED SSD1306 V1.0 demo - The Engineering Projects
  OLED found at 0x3C
  Type HELP for the commands
TEXT Hi there!:
  OK - text: Hi there!
STATUS:
  OLED 128x64 at 0x3C, found
  Screen: dashboard
  Text: Hi there! (size 2)
  Lower part: sine wave
  Contrast 207, inverse off, scroll off, display on
  Frames sent: 224
SCAN / SCROLL RIGHT (U2):
  I2C devices: 0x3D
  OK - scroll right
Without any OLED on the bus:
  No OLED found - check SDA (A4), SCL (A5), VCC

PROPERTIES (double-click the part > Edit Properties)
  PANEL       Simple devices only: the STATUS panel at the start, OPEN or
              CLOSED (default OPEN)
  ADDRESS     the I2C address: 0x3C (default) or 0x3D. The selector on the
              board follows it.
Every run starts again from the properties; the selector changes the address
for the run. A bad value is logged and 0x3C used. The panel style and the glass
colour are chosen by the device. The demo's Serial Monitors: BAUD 9600, THEME
TEPDARK, AUTOOPEN YES, QUICK1-4 as above.

LINKS.INI (OPTIONAL)
The Help page cards of the Advance devices open web pages. To point them
somewhere else without a new DLL, put a text file named links.ini next to
TEPOLED.DLL with lines KEY=URL, for example:
  ARTICLE=https://www.theengineeringprojects.com/...
Keys: WEBSITE, FORUM, BUG_REPORT, FEATURE_REQUEST, ARTICLE, USER_GUIDE,
UPDATE_CHECK, DONATE. Only http:// and https:// links are used; lines starting
with # are comments.

TROUBLESHOOTING
* The glass stays black and the PWR LED is off: no power - check VCC and GND
  (the panel says NO POWER with the voltage; the module needs 3.3 - 5 V).
* WAITING FOR I2C: nothing reached this address - check SDA -> A4, SCL -> A5
  (swapped lines look the same), and that the sketch runs.
* WRONG ADDRESS: the sketch writes to another address - change the address in
  the sketch (display.begin(..., 0x3D)), or the ADDRESS property / the
  selector (the I2C bus tool shows both).
* DARK - THE CHARGE PUMP IS OFF: the sketch switched the display on without
  8D 14 - use display.begin(SSD1306_SWITCHCAPVCC, ...), not SSD1306_EXTERNALVCC.
* Random dots: the RAM before the first frame - call display.display() after
  drawing (Adafruit draws into its buffer; nothing reaches the OLED before
  display()).
* Every second line / a stretched picture: 128x32 settings on this 128x64
  glass - Adafruit_SSD1306 display(128, 64, ...).
* Mirrored or upside down: the remap commands (A0 / A1, C0 / C8);
  display.setRotation(2) turns the picture in software instead.
* Slow or jerky animation: each display() sends 1 KB - at 100 kHz that is about
  a tenth of a second (Advance: Tests > Speed).
* The part is not simulated / no panel: TEPOLED.DLL is missing from MODELS and
  from the project folder. No monitor window: TEPSERIALMON.DLL is missing, or
  click OPEN MONITOR on the monitor part.
* Advance: the pop-up does not appear - click OPEN PANEL on the board, or turn
  "Open the panel at Run" on its Settings page back on.

BUG REPORTS AND FEATURE REQUESTS
Please post them in our forum with a screenshot, the Serial Monitor text, the
simulation log and (Advance) the Copy diagnostics text:
  https://www.theengineeringprojects.com/forum/category/oled-proteus-library

SUPPORT US
This library is free. If it saves you time, please support our work:
  https://www.theengineeringprojects.com/donate

WEBSITE
  https://www.theengineeringprojects.com/

LICENCES AND THIRD-PARTY NOTES
* The OLED model (TEPOLED.DLL), the symbols and artwork and the TEP Serial
  Monitor Advance (TEPSERIALMON.LIB / .DLL) are made by The Engineering
  Projects. The model is an independent implementation written from the
  SSD1306 datasheet. The models use only standard Windows libraries; no Visual
  C++ redistributable is needed.
  The C++ source code is not included.
* TEP Arduino UNO V3 library (ArduinoV3TEP.LIB / .IDX): The Engineering
  Projects, https://www.theengineeringprojects.com/2023/10/arduino-library-for-proteus-v30.html
* The demo sketch uses the Adafruit SSD1306 library 2.5.17 and the Adafruit
  GFX library 1.12.6 (BSD licence, Adafruit Industries:
  https://github.com/adafruit/Adafruit_SSD1306 and
  https://github.com/adafruit/Adafruit-GFX-Library; Adafruit BusIO 1.17.4 is
  installed with them) and Arduino's Wire library. The .hex file is built from
  the demo sketch, these libraries (without the Adafruit splash screen:
  SSD1306_NO_SPLASH) and the Arduino AVR core 1.8.6 (with Wire), which
  includes LGPL-licensed code; its source code is available at
  https://github.com/arduino/ArduinoCore-avr/tree/1.8.6
  The licence texts of the three Adafruit libraries are at the end of this file
  (THIRD-PARTY LICENCE TEXTS).
* Proteus is a product of Labcenter Electronics and is not included. Arduino is
  a trademark of Arduino SA. SSD1306 is a Solomon Systech part; this library is
  not made or endorsed by Solomon Systech, Adafruit or Labcenter.

REBUILDING THE FIRMWARE (OPTIONAL)
The HEX file is supplied; Arduino IDE is not needed to run the demo. To edit the
sketch, install "Adafruit SSD1306" from the Library Manager (it offers Adafruit
GFX and BusIO too - install them), open
Arduino Code\OLED_SSD1306_Demo\OLED_SSD1306_Demo.ino, select Arduino Uno and use
Sketch > Export Compiled Binary. Replace the simulation's .hex with the exported
HEX. (Built in the Arduino IDE the Adafruit splash screen is linked in - the
sketch never shows it, it only uses some flash.)

MODEL SCOPE AND LIMITS
Modelled: the SSD1306 I2C slave (0x3C / 0x3D, ACK, the control byte with Co
and D/C, command and data streams, parameters across transactions), the
fundamental, addressing, hardware-configuration, timing and scrolling commands
of the datasheet (81, 8D, A0 / A1, A3, A4 / A5, A6 / A7, A8, AE / AF, B0 - B7,
C0 / C8, D3, D5, D9, DA, DB, E3, 00 - 3F, 40 - 7F, 20, 21, 22, 26 / 27, 29 /
2A, 2E, 2F), the 128x64 GDDRAM with its random power-on content, this module's
wiring of the glass (A1 + C8 = upright, alternative COM pins), the panel
refresh from the clock and multiplex settings, the contrast as brightness on
the glass, VCC as a supply (on above 3.0 V, off below 2.5 V).
Not modelled: reading from the OLED (libraries never read it; a read is not
acknowledged), the fade / blink (23) and zoom (D6) extras of later datasheet
revisions (logged as unknown and ignored), the SPI and parallel interfaces
(other modules), an external VCC (this module has none), the effect of the
pre-charge and VCOMH settings on the picture (they are stored and shown), I2C
timing violations (any clock the AVR makes is accepted - the tools show it),
the current draw and pixel ageing.

VERSION
TEP OLED SSD1306 library V1.0 (Oct 2026). Devices OLED12864WHITETEP /
OLED12864WHITEADVTEP / OLED12864BLUETEP / OLED12864BLUEADVTEP /
OLED12864YELLOWBLUETEP / OLED12864YELLOWBLUEADVTEP, files TEPOLED12864.LIB /
TEPOLED.DLL. Demo sketch OLED_SSD1306_Demo V1.0. Demo monitor: TEP Serial
Monitor Advance v1.0.1 (SERIALMONTEP).

THIRD-PARTY LICENCE TEXTS
The demo's .hex contains code of these libraries (compiled):

--- Adafruit SSD1306 2.5.17 (https://github.com/adafruit/Adafruit_SSD1306) ---
Software License Agreement (BSD License)

Copyright (c) 2012, Adafruit Industries
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
3. Neither the name of the copyright holders nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

--- Adafruit GFX Library 1.12.6 (https://github.com/adafruit/Adafruit-GFX-Library) ---
Software License Agreement (BSD License)

Copyright (c) 2012 Adafruit Industries.  All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

--- Adafruit BusIO 1.17.4 (https://github.com/adafruit/Adafruit_BusIO) ---
The MIT License (MIT)

Copyright (c) 2017 Adafruit Industries

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
