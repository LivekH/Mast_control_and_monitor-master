// OLED SSD1306 Library for Proteus V1.0 - demo sketch: a 0.96" 128x64 I2C OLED on an Arduino UNO
// The Engineering Projects - www.TheEngineeringProjects.com
//
// Wiring: GND -> GND, VCC -> 5V, SCL -> A5, SDA -> A4. The sketch finds the OLED at 0x3C or 0x3D by itself.
// The dashboard: a header (the yellow rows of a yellow-blue OLED) with the address and the up time, a big text line and a
// moving sine wave (or a bar). Open the Serial Monitor (9600 baud) and type HELP for the commands.
// Libraries: Adafruit SSD1306 and Adafruit GFX (Arduino IDE: Sketch > Include Library > Manage Libraries).

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

Adafruit_SSD1306 display(128, 64, &Wire, -1);   // width, height, the I2C bus, no reset pin

// our TEP logo, 40 x 32 (made by tools/make-logo.py)
const uint8_t PROGMEM logo[] = {
  0x1F, 0xFF, 0xFF, 0xFF, 0xF8, 0x20, 0x00, 0x00, 0x00, 0x04, 0x40, 0x00, 0x00, 0x00, 0x02,
  0x80, 0x00, 0x00, 0x00, 0x01, 0x80, 0x00, 0x00, 0x00, 0x01, 0x80, 0x00, 0x00, 0x00, 0x01,
  0x9F, 0xF9, 0xFF, 0x9F, 0xE1, 0x9F, 0xF9, 0xFF, 0x9F, 0xE1, 0x81, 0x81, 0x80, 0x18, 0x19,
  0x81, 0x81, 0x80, 0x18, 0x19, 0x81, 0x81, 0x80, 0x18, 0x19, 0x81, 0x81, 0x80, 0x18, 0x19,
  0x81, 0x81, 0xFE, 0x1F, 0xE1, 0x81, 0x81, 0xFE, 0x1F, 0xE1, 0x81, 0x81, 0x80, 0x18, 0x01,
  0x81, 0x81, 0x80, 0x18, 0x01, 0x81, 0x81, 0x80, 0x18, 0x01, 0x81, 0x81, 0x80, 0x18, 0x01,
  0x81, 0x81, 0xFF, 0x98, 0x01, 0x81, 0x81, 0xFF, 0x98, 0x01, 0x80, 0x00, 0x00, 0x00, 0x01,
  0x80, 0x00, 0x00, 0x00, 0x01, 0x80, 0x00, 0x00, 0x00, 0x01, 0x83, 0xFF, 0xFF, 0xFF, 0xC1,
  0x83, 0xFF, 0xFF, 0xFF, 0xC1, 0x80, 0x00, 0x00, 0x00, 0x01, 0x80, 0x00, 0x00, 0x00, 0x01,
  0x80, 0x24, 0x92, 0x48, 0x01, 0x80, 0x00, 0x00, 0x00, 0x01, 0x40, 0x00, 0x00, 0x00, 0x02,
  0x20, 0x00, 0x00, 0x00, 0x04, 0x1F, 0xFF, 0xFF, 0xFF, 0xF8,
};

// one period of a sine, 32 steps, +-11 pixels (the wave on the dashboard)
const int8_t PROGMEM wave[32] = {0, 2, 4, 6, 8, 9, 10, 11, 11, 11, 10, 9, 8, 6, 4, 2,
                                 0, -2, -4, -6, -8, -9, -10, -11, -11, -11, -10, -9, -8, -6, -4, -2};

enum Screen { DASH, LOGO, SHAPES, BLANK };
Screen screen = DASH;
bool barMode = false;                  // the dashboard's lower part: false = the sine wave, true = a bar
int barPercent = 0;
char text[11] = "Hello, TEP";          // the big line (10 characters at size 2)
byte textSize = 2;
byte address = 0x3C;
bool found = false, inverted = false, displayOn = true;
byte contrast = 0xCF;                  // Adafruit's value for 128x64 with the internal charge pump
enum Scroll { S_OFF, S_LEFT, S_RIGHT, S_DIAG };
Scroll scroll = S_OFF;                 // the controller scrolls the RAM itself: no redraws meanwhile
unsigned long frames = 0, lastDraw = 0;
char cmd[40];
byte cmdLen = 0;

bool answers(byte a) {                 // an address check: does a device ACK?
  Wire.beginTransmission(a);
  return Wire.endTransmission() == 0;
}

void show() { display.display(); frames++; }

void header() {                        // rows 0-15: the yellow zone of a yellow-blue OLED
  unsigned long s = millis() / 1000;
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print(F("TEP OLED"));
  display.setCursor(98, 0);
  display.print(F("0x"));
  display.print(address, HEX);
  display.setCursor(0, 8);
  char buf[22];
  snprintf_P(buf, sizeof buf, PSTR("Up %02lu:%02lu:%02lu"), s / 3600 % 100, s / 60 % 60, s % 60);
  display.print(buf);
  snprintf_P(buf, sizeof buf, PSTR("F%lu"), frames % 100000);   // the frames sent, right-aligned
  display.setCursor(128 - 6 * strlen(buf), 8);
  display.print(buf);
}

void drawDash() {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  header();
  display.setTextSize(textSize);
  display.setCursor(0, 18);
  display.print(text);
  if (barMode) {                       // a bar 0..100 % with its value
    display.drawRect(0, 46, 100, 14, SSD1306_WHITE);
    display.fillRect(2, 48, barPercent * 96 / 100, 10, SSD1306_WHITE);
    display.setTextSize(1);
    display.setCursor(104, 49);
    display.print(barPercent);
    display.print('%');
  } else {                             // the sine wave, moving with the time
    int phase = (millis() / 125) % 32;
    for (int x = 0; x < 128; x++) {
      int y = 52 - (int8_t)pgm_read_byte(&wave[(x / 2 + phase) % 32]);
      display.drawPixel(x, y, SSD1306_WHITE);
    }
    display.drawFastHLine(0, 52, 128, SSD1306_WHITE);
  }
  show();
}

void drawLogo() {
  display.clearDisplay();
  display.drawBitmap(4, 16, logo, 40, 32, SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print(F("TEP OLED  0x"));
  display.print(address, HEX);
  display.setCursor(52, 22);
  display.print(F("The"));
  display.setCursor(52, 32);
  display.print(F("Engineering"));
  display.setCursor(52, 42);
  display.print(F("Projects"));
  show();
}

void drawShapes() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print(F("Shapes  -  GFX"));
  display.drawRect(0, 18, 30, 22, SSD1306_WHITE);
  display.fillRect(4, 22, 22, 14, SSD1306_WHITE);
  display.drawCircle(48, 34, 14, SSD1306_WHITE);
  display.fillCircle(48, 34, 6, SSD1306_WHITE);
  display.drawTriangle(70, 50, 84, 20, 98, 50, SSD1306_WHITE);
  display.drawRoundRect(104, 18, 24, 32, 6, SSD1306_WHITE);
  for (int x = 0; x < 128; x += 8) display.drawLine(x, 63, x + 8, 56, SSD1306_WHITE);
  show();
}

void help() {
  Serial.println(F("Commands:"));
  Serial.println(F("  TEXT <text>    the big line (10 characters)"));
  Serial.println(F("  SIZE <1-3>     its text size"));
  Serial.println(F("  GRAPH          the moving sine wave"));
  Serial.println(F("  BAR <0-100>    a bar instead of the wave"));
  Serial.println(F("  LOGO  SHAPES  DASH (the dashboard)"));
  Serial.println(F("  INVERT ON|OFF  CONTRAST <0-255>  DISPLAY ON|OFF"));
  Serial.println(F("  SCROLL LEFT|RIGHT|DIAG|STOP"));
  Serial.println(F("  CLEAR  SCAN  STATUS  HELP"));
}

void printScroll() {
  if (scroll == S_LEFT) Serial.print(F("left"));
  else if (scroll == S_RIGHT) Serial.print(F("right"));
  else if (scroll == S_DIAG) Serial.print(F("diagonal"));
  else Serial.print(F("off"));
}

void status() {
  Serial.print(F("OLED 128x64 at 0x")); Serial.print(address, HEX);
  Serial.println(found ? F(", found") : F(", NOT FOUND"));
  Serial.print(F("Screen: "));
  if (screen == DASH) Serial.println(F("dashboard"));
  else if (screen == LOGO) Serial.println(F("logo"));
  else if (screen == SHAPES) Serial.println(F("shapes"));
  else Serial.println(F("cleared"));
  Serial.print(F("Text: ")); Serial.print(text); Serial.print(F(" (size ")); Serial.print(textSize); Serial.println(')');
  Serial.print(F("Lower part: "));
  if (barMode) { Serial.print(F("bar ")); Serial.print(barPercent); Serial.println('%'); } else Serial.println(F("sine wave"));
  Serial.print(F("Contrast ")); Serial.print(contrast);
  Serial.print(F(", inverse ")); Serial.print(inverted ? F("on") : F("off"));
  Serial.print(F(", scroll ")); printScroll();
  Serial.print(F(", display ")); Serial.println(displayOn ? F("on") : F("off"));
  Serial.print(F("Frames sent: ")); Serial.println(frames);
}

void redraw() {
  if (screen == DASH) drawDash();
  else if (screen == LOGO) drawLogo();
  else if (screen == SHAPES) drawShapes();
}

void handle(char* line) {
  char* arg = strchr(line, ' ');
  if (arg) { *arg++ = 0; while (*arg == ' ') arg++; } else arg = line + strlen(line);
  if (!strcasecmp_P(line, PSTR("HELP"))) help();
  else if (!strcasecmp_P(line, PSTR("STATUS"))) status();
  else if (!strcasecmp_P(line, PSTR("SCAN"))) {
    Serial.print(F("I2C devices:"));
    byte k = 0;
    for (byte a = 8; a < 120; a++)
      if (answers(a)) { Serial.print(F(" 0x")); if (a < 16) Serial.print('0'); Serial.print(a, HEX); k++; }
    if (!k) Serial.print(F(" none - check SDA (A4), SCL (A5), VCC"));
    Serial.println();
  } else if (!strcasecmp_P(line, PSTR("TEXT"))) {
    strncpy(text, arg, 10); text[10] = 0;
    screen = DASH; drawDash();
    Serial.print(F("OK - text: ")); Serial.println(text);
  } else if (!strcasecmp_P(line, PSTR("SIZE"))) {
    textSize = constrain(atoi(arg), 1, 3);
    screen = DASH; drawDash();
    Serial.print(F("OK - text size ")); Serial.println(textSize);
  } else if (!strcasecmp_P(line, PSTR("GRAPH"))) {
    barMode = false; screen = DASH; drawDash(); Serial.println(F("OK - the sine wave"));
  } else if (!strcasecmp_P(line, PSTR("BAR"))) {
    barPercent = constrain(atoi(arg), 0, 100); barMode = true; screen = DASH; drawDash();
    Serial.print(F("OK - bar ")); Serial.print(barPercent); Serial.println('%');
  } else if (!strcasecmp_P(line, PSTR("LOGO"))) {
    screen = LOGO; drawLogo(); Serial.println(F("OK - the logo (drawBitmap)"));
  } else if (!strcasecmp_P(line, PSTR("SHAPES"))) {
    screen = SHAPES; drawShapes(); Serial.println(F("OK - shapes"));
  } else if (!strcasecmp_P(line, PSTR("DASH"))) {
    screen = DASH; drawDash(); Serial.println(F("OK - the dashboard"));
  } else if (!strcasecmp_P(line, PSTR("INVERT"))) {
    if (!strcasecmp_P(arg, PSTR("ON"))) inverted = true;
    else if (!strcasecmp_P(arg, PSTR("OFF"))) inverted = false;
    else { Serial.println(F("Use ON or OFF")); return; }
    display.invertDisplay(inverted);
    Serial.print(F("OK - inverse ")); Serial.println(inverted ? F("on") : F("off"));
  } else if (!strcasecmp_P(line, PSTR("CONTRAST"))) {
    contrast = constrain(atoi(arg), 0, 255);
    display.ssd1306_command(SSD1306_SETCONTRAST);
    display.ssd1306_command(contrast);
    Serial.print(F("OK - contrast ")); Serial.println(contrast);
  } else if (!strcasecmp_P(line, PSTR("DISPLAY"))) {
    if (!strcasecmp_P(arg, PSTR("ON"))) displayOn = true;
    else if (!strcasecmp_P(arg, PSTR("OFF"))) displayOn = false;
    else { Serial.println(F("Use ON or OFF")); return; }
    display.ssd1306_command(displayOn ? SSD1306_DISPLAYON : SSD1306_DISPLAYOFF);
    Serial.print(F("OK - display ")); Serial.println(displayOn ? F("on") : F("off"));
  } else if (!strcasecmp_P(line, PSTR("SCROLL"))) {
    if (!strcasecmp_P(arg, PSTR("LEFT"))) { display.startscrollleft(0x00, 0x07); scroll = S_LEFT; }
    else if (!strcasecmp_P(arg, PSTR("RIGHT"))) { display.startscrollright(0x00, 0x07); scroll = S_RIGHT; }
    else if (!strcasecmp_P(arg, PSTR("DIAG"))) { display.startscrolldiagright(0x00, 0x07); scroll = S_DIAG; }
    else if (!strcasecmp_P(arg, PSTR("STOP"))) { display.stopscroll(); scroll = S_OFF; redraw(); }
    else { Serial.println(F("Use LEFT, RIGHT, DIAG or STOP")); return; }
    Serial.print(F("OK - scroll ")); printScroll(); Serial.println();
  } else if (!strcasecmp_P(line, PSTR("CLEAR"))) {
    screen = BLANK; display.clearDisplay(); show();
    Serial.println(F("OK - cleared (DASH brings the dashboard back)"));
  } else {
    Serial.print(F("Unknown command: ")); Serial.println(line);
    Serial.println(F("Type HELP for the commands"));
  }
}

void setup() {
  Serial.begin(9600);
  Serial.println(F("OLED SSD1306 V1.0 demo - The Engineering Projects"));
  Wire.begin();
  if (answers(0x3C)) { address = 0x3C; found = true; }
  else if (answers(0x3D)) { address = 0x3D; found = true; }
  if (!display.begin(SSD1306_SWITCHCAPVCC, address)) {
    Serial.println(F("SSD1306: not enough RAM for the 1 KB buffer"));
    for (;;);
  }
  if (found) { Serial.print(F("OLED found at 0x")); Serial.println(address, HEX); }
  else Serial.println(F("No OLED found - check SDA (A4), SCL (A5), VCC"));
  drawLogo();                          // the logo for a second, then the dashboard
  delay(1000);
  drawDash();
  Serial.println(F("Type HELP for the commands"));
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\r' || c == '\n') {
      if (cmdLen) { cmd[cmdLen] = 0; handle(cmd); cmdLen = 0; }
    } else if (cmdLen < sizeof cmd - 1) cmd[cmdLen++] = c;
  }
  unsigned long now = millis();
  if (screen == DASH && scroll == S_OFF && now - lastDraw >= 500) {   // twice a second (not while it scrolls)
    lastDraw = now;
    drawDash();
  }
}
